package com.example.myapplication

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.MyApplicationTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // Contenido principal de la actividadGuardarEnSharedPreferences(this@MainActivity)
                    Main(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun Main(modifier: Modifier = Modifier) {
    var nombre by remember { mutableStateOf("") }
    var edad by remember { mutableStateOf("") }
    var mostrarDatos by remember { mutableStateOf(false) }
    var datosGuardados by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var poderGuardar by remember { mutableStateOf(false) }
    LaunchedEffect(nombre, edad){
        poderGuardar = nombre.isNotEmpty() && edad.isNotEmpty()
    }
    Column(
        modifier = modifier.padding(16.dp)
    ) {
        TextField( value = nombre, label = {Text("Nombre")}, onValueChange = { nombre = it }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
        TextField( value = edad, label = {Text("Edad")}, onValueChange = { edad = it }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            GuardarEnSharedPreferences(context, nombre, edad.toInt())
            datosGuardados = !datosGuardados
            mostrarDatos = false
            nombre = ""
            edad = ""

        }, enabled = poderGuardar) { Text("Guardar") }
        Button(onClick = {mostrarDatos = true}) { Text("Mostrar") }
        if (mostrarDatos){
            MostrarDatosGuardados(context = context, datosGuardados = datosGuardados)
        }

    }

}



fun GuardarEnSharedPreferences(context: Context, nombre: String, edad: Int) {
    // Obtener SharedPreferences
    val sharedPreferences =
        context.getSharedPreferences("mis_preferencias", Context.MODE_PRIVATE)


    // Guardar datos en SharedPreferences
    val editor = sharedPreferences.edit()
    editor.putString("Nombre", nombre)
    editor.putInt("Edad", edad)
    editor.apply()


}

@Composable
fun MostrarDatosGuardados(context: Context, datosGuardados: Boolean) {
    val sharedPreferences = context.getSharedPreferences("mis_preferencias", MODE_PRIVATE)
    val nombre = sharedPreferences.getString("Nombre", "No hay nombre guardado") ?: "No hay nombre guardado"
    val edad = sharedPreferences.getInt("Edad", -1)
    val edadString = if (edad != -1) edad.toString() else "No hay edad guardada"

    Column(modifier = Modifier.padding(top = 16.dp)) {
        Text(text = "Nombre guardado: $nombre")
        Text(text = "Edad guardada: $edadString")
    }
}
