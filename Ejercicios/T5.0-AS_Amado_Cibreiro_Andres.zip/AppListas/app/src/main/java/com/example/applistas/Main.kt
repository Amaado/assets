package com.example.applistas

import Pantalla1
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable


@Composable
fun Main() {
    val navController: NavHostController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = Rutas.Pantalla1.route
    ){
        composable(Rutas.Pantalla1.route) { Pantalla1(navController) }
        composable(Rutas.Pantalla2.route) { Pantalla2(navController) }
        composable(Rutas.Pantalla3.route) { Pantalla3(navController) }
        composable(Rutas.Pantalla4.route) { Pantalla4(navController) }

    }
}