import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.applistas.Rutas


@Composable
fun Pantalla1(navController: NavHostController) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(30.dp)
    ) {
        Text(
            text = "Aplicación para ver diferentes listas",
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .padding(16.dp)
                .fillMaxSize()
        ) {
            Button(
                onClick = { navController.navigate(Rutas.Pantalla2.route) },
                modifier = Modifier
                    .weight(1f)
                    .wrapContentSize(Alignment.Center)
            ) {
                Text(
                    text = "Ver ListView",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp
                )
            }
            Button(
                onClick = { navController.navigate(Rutas.Pantalla3.route) },
                modifier = Modifier.weight(1f).wrapContentSize(Alignment.Center)
            ) {
                Text(
                    text = "Ver GridView",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp
                )
            }
            Button(
                onClick = { navController.navigate(Rutas.Pantalla4.route) },
                modifier = Modifier.weight(1f).wrapContentSize(Alignment.Center)
            ) {
                Text(
                    text = "Ver Spinner",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp
                )
            }

        }
    }
}