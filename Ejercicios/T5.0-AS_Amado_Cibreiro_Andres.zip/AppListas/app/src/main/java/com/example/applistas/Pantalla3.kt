package com.example.applistas

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun Pantalla3(navController: NavHostController) {

    val items=listOf("Madrid","París","Berlín","Londres","Roma","Lisboa","Ámsterdam","Viena","Atenas","Dublín","Varsovia","Oslo" )
    LazyVerticalGrid(
        columns = GridCells.Fixed(2) // Define 2 columnas
    ) {
        items(items) { item ->
            Text(text = item, modifier = Modifier.padding(16.dp))
        }
    }

}