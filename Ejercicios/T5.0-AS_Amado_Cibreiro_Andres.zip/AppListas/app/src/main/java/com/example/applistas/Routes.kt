package com.example.applistas

sealed class Rutas(val route: String) {
    object Pantalla1 : Rutas("pantalla1")
    object Pantalla2 : Rutas("pantalla2")
    object Pantalla3 : Rutas("pantalla3")
    object Pantalla4 : Rutas("pantalla4")

}