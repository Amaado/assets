package entities;


import jakarta.persistence.*;


import java.io.Serializable;
@Entity
@Table(name="empleado")
public class Empleado implements Serializable {
    @Id
    @Column(name="dni",length = 9,nullable = false)
    private String dni;
    @Column(name="nom_emp",length = 40,nullable = false)
    private String nomEmp;
    @ManyToOne
    @JoinColumn(name = "id_depto", nullable = false)
    private Departamento idDepto;

    public Empleado(){}

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNomEmp() {
        return nomEmp;
    }

    public void setNomEmp(String nomEmp) {
        this.nomEmp = nomEmp;
    }

    public Departamento getIdDepto() {
        return idDepto;
    }

    public void setIdDepto(Departamento idDepto) {
        this.idDepto = idDepto;
    }
}
