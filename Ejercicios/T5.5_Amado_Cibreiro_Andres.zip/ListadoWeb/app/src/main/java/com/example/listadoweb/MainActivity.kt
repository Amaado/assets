package com.example.listadoweb


import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.example.listadoweb.ui.theme.ListadoWebTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ListadoWebTheme {
                WebSpinnerScreen()

            }
        }
    }
}
data class WebItem(
    val imageRes: Int,
    val title: String,
    val subtitle: String,
    val url: String
)
val webItems = listOf(
    WebItem(
        imageRes = R.drawable.mona_lisa,
        title = "Leonardo da Vinci",
        subtitle = "La Gioconda",
        url = "https://es.wikipedia.org/wiki/Leonardo_da_Vinci"
    ),
    WebItem(
        imageRes = R.drawable.grito,
        title = "Edvard Munch",
        subtitle = "El grito",
        url = "https://es.wikipedia.org/wiki/Edvard_Munch"
    ),
    WebItem(
        imageRes = R.drawable.venus,
        title = " Sandro Botticelli",
        subtitle = "El nacimiento de Venus",
        url = "https://es.wikipedia.org/wiki/Sandro_Botticelli"

    ), WebItem(
        imageRes = R.drawable.nocheestrella,
        title = "Vincent van Gogh",
        subtitle = "La noche estrellada",
        url = "https://es.wikipedia.org/wiki/Vincent_van_Gogh"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebSpinnerScreen() {
    var expanded by remember { mutableStateOf(false) }
    var selectedItem by remember { mutableStateOf(webItems[0]) }
    val context = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        Spacer(modifier = Modifier.height(50.dp))
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = it }
        ) {
            Row(
                modifier = Modifier
                    .menuAnchor()
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(selectedItem.imageRes),
                    contentDescription = null,
                    modifier = Modifier.size(80.dp).background(Color.Cyan)
                )
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .background(Color.Cyan),
                    horizontalAlignment = Alignment.CenterHorizontally,

                ) {
                    Text(
                        selectedItem.title,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        selectedItem.subtitle,
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }

            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                webItems.forEach { item ->
                    DropdownMenuItem(
                        onClick = {
                            selectedItem = item
                            expanded = false
                        },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Image(
                                    painter = painterResource(item.imageRes),
                                    contentDescription = null,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(Modifier.width(16.dp))
                                Column {
                                    Text(
                                        item.title,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        item.subtitle,
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    )
                }
            }
        }

        WebViewScreen(url = selectedItem.url)
    }
}

@Composable
fun WebViewScreen(url: String) {
    val context = LocalContext.current
    val webView = remember { WebView(context).apply {
        webViewClient = WebViewClient()
        settings.javaScriptEnabled = true
    } }

    AndroidView(
        factory = { webView },
        update = { view -> view.loadUrl(url) },
        modifier = Modifier.fillMaxSize()
    )
}


