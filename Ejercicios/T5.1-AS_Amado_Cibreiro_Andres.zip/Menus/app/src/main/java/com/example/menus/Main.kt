package com.example.menus

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun Main(modifier: Modifier){
    val navController= rememberNavController()
    NavHost(navController=navController, startDestination = Routes.Principal.route){
        composable(Routes.Principal.route){ Principal(navController)}
        composable(Routes.Inicio.route){Inicio(navController)}
        composable(Routes.Productos.route){ Productos(navController,modifier) }
        composable(Routes.Tarifas.route) { Tarifas(navController,modifier) }
        composable(Routes.Contacto.route) { Contacto(navController,modifier) }

    }
}