package com.example.menus

sealed class Routes(val route: String) {
    object Principal : Routes("principal")
    object Inicio : Routes("inicio")
    object Tarifas : Routes("tarifas")
    object Productos : Routes("productos")
    object Contacto : Routes("contacto")


}