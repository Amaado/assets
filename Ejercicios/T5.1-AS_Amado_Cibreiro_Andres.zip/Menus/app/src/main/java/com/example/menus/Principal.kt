package com.example.menus

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.navigation.NavController

@Composable
fun Principal(navController: NavController) {
    var showMenu by remember { mutableStateOf(false) }
    var showSubMenu by remember { mutableStateOf(false) }
    var selectedOptionText by remember { mutableStateOf("Abrir Menú") }

    var tarifasPosition by remember { mutableStateOf(Offset.Zero) }
    var tarifasSize by remember { mutableStateOf(IntSize.Zero) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .wrapContentSize(Alignment.TopStart)
                .align(Alignment.TopStart)
        ) {
            Button(onClick = { showMenu = true }) {
                Text(selectedOptionText)
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = {
                    showMenu = false
                    showSubMenu=false },
                modifier = Modifier.width(200.dp)
            ) {
                DropdownMenuItem(
                    text = { Text("Inicio") },
                    onClick = {
                        showMenu = false
                        selectedOptionText = "Inicio"
                        navController.navigate(Routes.Inicio.route)
                    }
                )

                DropdownMenuItem(
                    text = { Text("Tarifas") },
                    onClick = { showSubMenu = true },
                    modifier = Modifier.onGloballyPositioned { coords ->
                        tarifasPosition = coords.positionInParent()
                        tarifasSize = coords.size
                    }
                )

                DropdownMenuItem(
                    text = { Text("Productos") },
                    onClick = {
                        showMenu = false
                        selectedOptionText = "Productos"
                        navController.navigate(Routes.Productos.route)
                    }
                )

                DropdownMenuItem(
                    text = { Text("Contacto") },
                    onClick = {
                        showMenu = false
                        selectedOptionText = "Contacto"
                        navController.navigate(Routes.Contacto.route)
                    }
                )
            }
        }

        if (showSubMenu) {
            val density = LocalDensity.current
            val mainMenuWidth = 200.dp

            Popup(
                alignment = Alignment.TopStart,
                offset = with(density) {
                    IntOffset(
                        x = (tarifasPosition.x + mainMenuWidth.toPx()).toInt(),
                        y = tarifasPosition.y.toInt()
                    )
                }
            ) {
                Surface(
                    modifier = Modifier.width(200.dp),
                    shadowElevation = 8.dp,
                    shape = MaterialTheme.shapes.medium
                ) {
                    Column {
                        listOf("Tarifa 1", "Tarifa 2", "Tarifa 3", "Tarifa 4").forEach { tarifa ->
                            DropdownMenuItem(
                                text = { Text(tarifa) },
                                onClick = {
                                    showSubMenu = false
                                    showMenu = false

                                }
                            )
                        }
                    }
                }
            }
        }
    }
}