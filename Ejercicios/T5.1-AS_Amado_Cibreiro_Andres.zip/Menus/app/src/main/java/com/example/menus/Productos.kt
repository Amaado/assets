package com.example.menus

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController

@Composable
fun Productos(navController: NavController,modifier: Modifier) {
    Column(

    ) {
        Text("Productos")
        Button(onClick = { navController.navigate(Routes.Principal.route) }) {
            Text("Volver")
        }
    }
}