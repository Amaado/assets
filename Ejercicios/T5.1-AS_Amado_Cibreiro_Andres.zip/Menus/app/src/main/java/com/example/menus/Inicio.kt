package com.example.menus

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun Inicio(navController: NavController) {
    var showMenu by remember { mutableStateOf(false) }
    var clickOffset by remember { mutableStateOf(Offset.Zero) }
    var textPosition by remember { mutableStateOf(Offset.Zero) }
    val density = LocalDensity.current

    Box() {
        Text(
            text = "Productos\nPresiona para ver menú contextual",
            modifier = Modifier
                .padding(16.dp)
                .onGloballyPositioned {
                    textPosition = it.positionInRoot()
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onLongPress = { offset ->
                            clickOffset = offset
                            showMenu = true
                        }
                    )
                }
        )

        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false },
            offset = with(density) {
                DpOffset(
                    x = textPosition.x.toDp(),
                    y = (textPosition.y + clickOffset.y).toDp()
                )
            }
        ) {
            DropdownMenuItem(
                text = { Text("Añadir") },
                onClick = { showMenu = false }
            )
            DropdownMenuItem(
                text = { Text("Copiar") },
                onClick = { showMenu = false }
            )
            DropdownMenuItem(
                text = { Text("Eliminar") },
                onClick = { showMenu = false }
            )
        }
    }

}