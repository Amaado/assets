package entities;

import java.io.Serializable;
import java.util.Objects;

public class ProyectoSedeId implements Serializable {
    private int idProy;
    private int idSede;

    public ProyectoSedeId() {}

    public ProyectoSedeId(int idProy, int idSede) {
        this.idProy = idProy;
        this.idSede = idSede;
    }

    public int getIdProy() { return idProy; }
    public void setIdProy(int idProy) { this.idProy = idProy; }

    public int getIdSede() { return idSede; }
    public void setIdSede(int idSede) { this.idSede = idSede; }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProyectoSedeId that = (ProyectoSedeId) o;
        return idProy == that.idProy && idSede == that.idSede;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProy, idSede);
    }
}
