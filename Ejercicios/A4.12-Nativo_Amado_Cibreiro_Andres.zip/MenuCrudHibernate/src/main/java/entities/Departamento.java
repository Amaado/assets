package entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="departamento")
public class Departamento implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_depto",unique = true,nullable = false)
    private int idDepto;
    @Column(name = "nom_depto",length = 32,nullable = false)
    private String nomDepto;
    @ManyToOne
    @JoinColumn(name = "id_sede", nullable = true)
    private Sede idSede;
    @OneToMany(mappedBy = "idDepto", cascade = CascadeType.ALL)
    private List<Empleado> empleados = new ArrayList<>();




    public Departamento(){}

    public int getIdDepto() {
        return idDepto;
    }

    public void setIdDepto(int idDepto) {
        this.idDepto = idDepto;
    }

    public String getNomDepto() {
        return nomDepto;
    }

    public void setNomDepto(String nomDepto) {
        this.nomDepto = nomDepto;
    }

    public Sede getIdSede() {
        return idSede;
    }

    public void setIdSede(Sede idSede) {
        this.idSede = idSede;
    }
    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }

    @Override
    public String toString() {
        return "Departamento{" +
                "idDepto=" + idDepto +
                ", nomDepto='" + nomDepto + '\'' +
                ", idSede=" + idSede +
                '}';
    }
}
