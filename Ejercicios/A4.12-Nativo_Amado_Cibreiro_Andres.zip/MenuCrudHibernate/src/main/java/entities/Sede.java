package entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="sede")
public class Sede implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_sede", unique = true, nullable = false)
    private int idSede;
    @Column(name="nom_sede",nullable = false,length=20)
    private String nomSede;
    @OneToMany(mappedBy = "idSede", cascade = CascadeType.REMOVE)
    private List<Departamento> departamentos = new ArrayList<>();

    @OneToMany(mappedBy = "idSede",cascade = CascadeType.REMOVE)
    private List<ProyectoSede> proyectoSedes=new ArrayList<>();



    public Sede(){}


    public int getIdSede() {
        return idSede;
    }

    public void setIdSede(int idSede) {
        this.idSede = idSede;
    }

    public String getNomSede() {
        return nomSede;
    }

    public void setNomSede(String nomSede) {
        this.nomSede = nomSede;
    }

    public List<Departamento> getDepartamentos() {
        return departamentos;
    }

    public void setDepartamentos(List<Departamento> departamentos) {
        this.departamentos = departamentos;
    }

    public List<ProyectoSede> getProyectoSedes() {
        return proyectoSedes;
    }

    public void setProyectoSedes(List<ProyectoSede> proyectoSedes) {
        this.proyectoSedes = proyectoSedes;
    }

    @Override
    public String toString() {
        return "Sede{" +
                "idSede=" + idSede +
                ", nomSede='" + nomSede + '\'' +
                '}';
    }
}
