import entities.Sede;
import jakarta.persistence.EntityManager;
import util.JPAUtil;

import java.util.Scanner;

public class HibernateEditar {
    public static void main(String[] args) {

        EntityManager em= JPAUtil.getEntityManager();

        try{
            Scanner scanner = new Scanner(System.in);
            System.out.println("Introduce el id de la sede:");
            int id=scanner.nextInt();
            scanner.nextLine();
            Sede sede = em.find(Sede.class,id);//Ubicamos la sede, da null si no existe, TODO gestionar eso
            System.out.println("Introduce el nuevo nombre de la sede:"+sede.getNomSede());
            String nombre=scanner.nextLine();

            em.getTransaction().begin();//Iniciar
            sede.setNomSede(nombre);
            em.merge(sede);//Actualizr
            em.getTransaction().commit();//Finalizar
            System.out.println(sede);//Imprimir resultado para confirmar

        }catch (Exception e){
            em.getTransaction().rollback();
            e.printStackTrace();
        }finally {
            em.close();

        }
    }
}
