package services;

import entities.Departamento;
import entities.Sede;
import jakarta.persistence.EntityManager;
import repositories.JPACrudRepositoy;

import java.util.List;

public class SedeService {
    private EntityManager em;
    private JPACrudRepositoy<Sede,Integer> sedeRepository;
    public SedeService(EntityManager em) {
        this.em = em;
        this.sedeRepository=new JPACrudRepositoy<>(em, Sede.class);
    }

    public List<Sede> listarSedes(){
        return sedeRepository.listar();
    }

    public Sede encontrarSedeID(int id){
        return sedeRepository.porId(id);
    }

    public void guardarSede(Sede sede ){
        try{

            em.getTransaction().begin();
            sedeRepository.guardar(sede);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la insercción");
            e.printStackTrace();

        }
    }
    public void actualizarSede(Sede sede){
        try{

            em.getTransaction().begin();
            sedeRepository.actualizar(sede);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la insercción");
            e.printStackTrace();

        }

    }

    public void eliminarSede(int id){
        try {
            em.getTransaction().begin();
            Sede sede = sedeRepository.porId(id);
            if (sede != null) {
                List<Departamento> departamentos = sede.getDepartamentos();
                for (Departamento d : departamentos) {
                    d.setIdSede(null);
                    em.merge(d);
                }
                sedeRepository.eliminar(id);
                System.out.println("Sede eliminada correctamente.");
            } else {
                System.out.println("Sede no encontrada.");
            }

            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la acción.");
            e.printStackTrace();
        }

    }
    /*public void cambiarSedeDepartamento(Departamento departamento, Sede sede){
        em.getTransaction().begin();
        if(departamento.getIdSede()!=null){
            departamento.getIdSede().getDepartamentos().remove(departamento);
        }
        departamento.setIdSede(sede);
        sede.getDepartamentos().add(departamento);
        departamentoRepository.actualizar(departamento);
        em.getTransaction().rollback();

    }*/
}
