package services;

import entities.Departamento;
import entities.Empleado;
import entities.Sede;
import jakarta.persistence.EntityManager;
import repositories.JPACrudRepositoy;

import java.util.List;

public class DepartamentoService  {
    private EntityManager em;
    private JPACrudRepositoy<Departamento,Integer> departamentoRepository;
    public DepartamentoService(EntityManager em) {
        this.em = em;
        this.departamentoRepository=new JPACrudRepositoy<>(em, Departamento.class);
    }

    public List<Departamento> listarDepartamentos(){
        return departamentoRepository.listar();
    }

    public Departamento encontrarDepartamentoID(int id){
        return departamentoRepository.porId(id);
    }

    public void guardarDepartmaento(Departamento departamento ){
        try{

            em.getTransaction().begin();
            departamentoRepository.guardar(departamento);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la insercción");
            e.printStackTrace();

        }
    }
    public void actualizarDepartamento(Departamento departamento){
        try{

            em.getTransaction().begin();
            departamentoRepository.actualizar(departamento);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la insercción");
            e.printStackTrace();

        }

    }

    public void eliminarDepartametno(int id){
        try{

            em.getTransaction().begin();
            departamentoRepository.eliminar(id);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la acción");
            e.printStackTrace();

        }

    }
    public void cambiarSedeDepartamento(Departamento departamento, Sede sede){
        em.getTransaction().begin();
        if(departamento.getIdSede()!=null){
            departamento.getIdSede().getDepartamentos().remove(departamento);
        }
        departamento.setIdSede(sede);
        sede.getDepartamentos().add(departamento);
        departamentoRepository.actualizar(departamento);
        em.getTransaction().rollback();

    }
}
