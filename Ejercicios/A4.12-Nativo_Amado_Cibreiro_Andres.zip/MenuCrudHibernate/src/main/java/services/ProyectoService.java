package services;

import entities.Proyecto;
import entities.ProyectoSede;
import entities.Sede;
import jakarta.persistence.EntityManager;
import repositories.JPACrudRepositoy;

import java.sql.Date;
import java.util.List;

public class ProyectoService {
    private EntityManager em;
    private JPACrudRepositoy<Proyecto,Integer> proyectoRepository;
    public ProyectoService(EntityManager em) {
        this.em = em;
        this.proyectoRepository=new JPACrudRepositoy<>(em, Proyecto.class);
    }

    public List<Proyecto> listarProyectos(){
        return proyectoRepository.listar();
    }

    public Proyecto encontrarProyectoID(int id){
        return proyectoRepository.porId(id);
    }

    public void guardaProyecto(Proyecto proyecto){
        try{

            em.getTransaction().begin();
            proyectoRepository.guardar(proyecto);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la insercción");
            e.printStackTrace();

        }
    }
    public void actualizarProyecto(Proyecto proyecto){
        try{

            em.getTransaction().begin();
            proyectoRepository.actualizar(proyecto);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la insercción");
            e.printStackTrace();

        }

    }
    public void actualizarProyectoConSede(int idProy, Integer nuevaSedeId) {
        try {
            em.getTransaction().begin();

            Proyecto proyecto = proyectoRepository.porId(idProy);
            if (proyecto == null) {
                System.out.println("Proyecto no encontrado.");
                return;
            }
            // Actualizar sede del proyecto
            if (nuevaSedeId != null) {
                Sede nuevaSede = em.find(Sede.class, nuevaSedeId);
                if (nuevaSede != null) {
                    ProyectoSede proyectoSede = new ProyectoSede();
                    proyectoSede.setIdProy(idProy);
                    proyectoSede.setIdSede(nuevaSedeId);
                    proyectoSede.setfInicio(proyecto.getfInicio());
                    proyectoSede.setfFin(proyecto.getfFin());

                    em.merge(proyectoSede);
                    System.out.println("Sede del proyecto actualizada correctamente.");
                } else {
                    System.out.println("ID de sede no encontrado. Se mantiene la sede actual.");
                }
            }

            // Guardar cambios del proyecto
            proyectoRepository.actualizar(proyecto);

            em.getTransaction().commit();
            System.out.println("Proyecto actualizado correctamente.");

        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Error al actualizar el proyecto.");
            e.printStackTrace();
        }
    }

    public void eliminarProyecto(int id){
        try{
            em.getTransaction().begin();
            proyectoRepository.eliminar(id);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la acción");
            e.printStackTrace();
        }
    }
}
