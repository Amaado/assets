package services;

import entities.Departamento;
import entities.Empleado;
import entities.EmpleadoDatosProf;
import jakarta.persistence.EntityManager;
import repositories.JPACrudRepositoy;

import java.util.List;

public class EmpleadoService  {
    private EntityManager em;
    private JPACrudRepositoy<Empleado,String> empleadoRepository;

    public EmpleadoService(EntityManager em) {
        this.em = em;
        this.empleadoRepository=new JPACrudRepositoy<>(em, Empleado.class);
    }

    public List<Empleado> listarEmpleados(){
        return empleadoRepository.listar();
    }

    public Empleado encontrarEmpleadoID(String id){
        return empleadoRepository.porId(id);
    }

    public void guardarEmpleado(Empleado empleado){
        try{

            em.getTransaction().begin();
            empleadoRepository.guardar(empleado);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la insercción");
            e.printStackTrace();

        }
    }
    public void actualizarEmpleado(Empleado empleado){
        try{

            em.getTransaction().begin();
            empleadoRepository.actualizar(empleado);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la insercción");
            e.printStackTrace();

        }

    }

    public void eliminarEmpleado(String id){
        try{

            em.getTransaction().begin();
            empleadoRepository.eliminar(id);
            em.getTransaction().commit();

        }catch (Exception e){
            em.getTransaction().rollback();
            System.out.println("No se ha podido ejecutar la acción");
            e.printStackTrace();

        }

    }

    public void asignarDatosProfesionales(Empleado empleado, EmpleadoDatosProf empleadoDatosProf){
        em.getTransaction().begin();
        empleado.setEmpleadoDatosProf(empleadoDatosProf);
        empleadoDatosProf.setEmpleado(empleado);
        em.getTransaction().commit();
    }
    public void cambiarDepartamentoEmpleado(Empleado empleado, Departamento departamento){
        //En este método lo que tenemos que hacer es borrar de la lista del antiguo departamento al empleado y añadirlo al nuevo departamento, además de añadir el nuevo departamento a la tabla del empleado
        em.getTransaction().begin();
        if(empleado.getIdDepto()!=null){//En caso de que aún no tenga departamento
            empleado.getIdDepto().getEmpleados().remove(empleado);
        }
        empleado.setIdDepto(departamento);
        departamento.getEmpleados().add(empleado);
        empleadoRepository.actualizar(empleado);
        em.getTransaction().commit();
    }


}
