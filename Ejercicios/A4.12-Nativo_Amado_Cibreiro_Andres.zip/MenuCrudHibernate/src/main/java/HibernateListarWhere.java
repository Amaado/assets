import entities.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import util.JPAUtil;

import java.util.List;

public class HibernateListarWhere {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        Query query=em.createQuery("SELECT e FROM Empleado e WHERE e.nomEmp=:nomEmp",Empleado.class);
        query.setParameter("nomEmp","Pablo Botana");
        List<Empleado> empleado = query.getResultList();
        empleado.forEach(System.out::println);
        em.close();

    }
}
