package main;

import entities.*;
import jakarta.persistence.EntityManager;
import services.DepartamentoService;
import services.EmpleadoService;
import services.ProyectoService;
import services.SedeService;
import util.JPAUtil;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final EntityManager em= JPAUtil.getEntityManager();
    private static final EmpleadoService empleadoService= new EmpleadoService(em);
    private static final DepartamentoService departamentoService=new DepartamentoService(em);
    private static final SedeService sedeService = new SedeService(em);
    private static final ProyectoService proyectoService = new ProyectoService(em);

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        while (true){
            System.out.println("Bienvendio al menú");
            System.out.println("1.Sección Empleados");
            System.out.println("2.Sección Departamentos");
            System.out.println("3.Sección Proyectos");
            System.out.println("4.Sección Sede");
            System.out.println("5.Salir del programa");
            int opcion=scanner.nextInt();
            scanner.nextLine();

            switch (opcion){
                case 1:
                    System.out.println("1.Listar empleados:");
                    System.out.println("2.Encontrar un empleado por dni");
                    System.out.println("3.Agregar un nuevo empleado");
                    System.out.println("4.Asignar departamento a un empleado");
                    System.out.println("5.Actualizar un empleado");
                    System.out.println("6.Añadir datos profesionales");
                    System.out.println("7.Eliminar un empleado");
                    System.out.println("8.Volver al menú principal");
                    int seleccion=scanner.nextInt();
                    scanner.nextLine();

                    switch (seleccion){
                        case 1://Listar
                            System.out.println("Lista de empleados:*********************");
                           empleadoService.listarEmpleados().forEach(System.out::println);
                            System.out.println("Fin de la lista de empelados:*********************");
                            break;
                        case 2://Encontrar id
                            System.out.println("Introduce el dni del empleado:");
                            String dni = scanner.nextLine();
                            Empleado empleado=empleadoService.encontrarEmpleadoID(dni);
                            if(empleado==null){
                                System.out.println("No se ha podido encontrar el empleado");
                            }else{
                                System.out.println(empleado);
                            }
                            break;
                        case 3://Agregar empleado
                            empleado= new Empleado();
                            System.out.println("Introduce el dni del empleado:");
                            dni=scanner.nextLine();
                            empleado.setDni(dni);
                            System.out.println("Introduce el nombre del empleado");
                            String nombreEmp=scanner.nextLine();
                            empleado.setNomEmp(nombreEmp);
                            empleado.setIdDepto(null);
                            empleadoService.guardarEmpleado(empleado);
                            System.out.println("Empleado creado con éxito");
                            break;
                        case 4://Asignar departamento
                            System.out.println("Introduce el dni del empleado");
                            dni=scanner.nextLine();
                            empleado=empleadoService.encontrarEmpleadoID(dni);
                            if(empleado==null){
                                System.out.println("No se ha podido encontrar el empleado");
                            }else{
                                System.out.println("Introduce el id del departamento");
                                int idDept=scanner.nextInt();
                                scanner.nextLine();
                                Departamento departamento = departamentoService.encontrarDepartamentoID(idDept);
                                if(departamento==null){
                                    System.out.println("No se ha encontrado ese departamento");
                                }else {
                                    empleadoService.cambiarDepartamentoEmpleado(empleado,departamento);
                                    System.out.println("Departamento actualizado");
                                }
                            }
                            break;
                        case 5://Actualizar empleado
                            System.out.println("Introduce el dni del empleado a actualizar:");
                            dni=scanner.nextLine();
                            empleado=empleadoService.encontrarEmpleadoID(dni);
                            if(empleado==null){
                                System.out.println("No se ha podido encontrar el empleado");
                            }else{
                                System.out.println(empleado);
                                System.out.println("Introduce el nuevo nombre de empleado");
                                String nombEmp=scanner.nextLine();
                                System.out.println("Introduce el nuevo departamento");
                                int idDept=scanner.nextInt();
                                scanner.nextLine();
                                Departamento departamento = departamentoService.encontrarDepartamentoID(idDept);
                                if(departamento==null){
                                    System.out.println("No se ha encontrado ese departamento");
                                }else {
                                    empleado.setNomEmp(nombEmp);
                                    empleadoService.cambiarDepartamentoEmpleado(empleado,departamento);
                                    empleadoService.actualizarEmpleado(empleado);
                                    System.out.println("Empleado actualizado");
                                }

                            }
                            break;
                        case 6://Añadir datos profesionales
                            System.out.println("Introduce el dni del empleado:");
                            dni=scanner.nextLine();
                            empleado=empleadoService.encontrarEmpleadoID(dni);
                            if(empleado==null){
                                System.out.println("No se ha podido encontrar el empleado");
                            }else{
                                EmpleadoDatosProf empleadoDatosProf=new EmpleadoDatosProf();
                                System.out.println("Introduce la categoría:");
                                String categoriaEmp=scanner.nextLine();
                                System.out.println("Introduce el sueldo del empleado:");
                                double sueldo=scanner.nextDouble();
                                scanner.nextLine();
                                empleadoDatosProf.setCategoria(categoriaEmp);
                                empleadoDatosProf.setSueldoBrutoAnual(BigDecimal.valueOf(sueldo));
                                empleadoService.asignarDatosProfesionales(empleado,empleadoDatosProf);
                                System.out.println("Datos profesionales actualizados");

                            }
                            break;

                        case 7://Eliminar empleado
                            System.out.println("Introduce el dní del empleado a eliminar:");
                            dni=scanner.nextLine();
                            empleado=empleadoService.encontrarEmpleadoID(dni);
                            if(empleado==null){
                                System.out.println("No se ha podido encontrar el empleado");
                            }else{
                                empleadoService.eliminarEmpleado(dni);
                                System.out.println("Empleado eliminado");
                            }
                            break;

                        case 8://Salir
                            System.out.println("Volviendo al menú principal");
                            break;
                        default:
                            System.out.println("Opción no válida, volviendo al menú principal");
                            break;

                    }
                    break;
                case 2:
                    System.out.println("1.Listar departamentos:");
                    System.out.println("2.Encontrar un departamentos por id");
                    System.out.println("3.Agregar un nuevo departamento");
                    System.out.println("4.Actualizar un departamento");
                    System.out.println("5.Eliminar un departamento");
                    System.out.println("6.Volver al menú principal");
                    seleccion=scanner.nextInt();
                    scanner.nextLine();
                    switch (seleccion){
                        case 1:
                            System.out.println("Lista de departamentos:**************");
                            departamentoService.listarDepartamentos().forEach(System.out::println);
                            System.out.println("Fin de la lista de departamentos:*********************");
                            break;

                        case 2:
                            System.out.println("Escribe el id del departamento:");
                            int idDept=scanner.nextInt();
                            scanner.nextLine();
                            Departamento departamento=departamentoService.encontrarDepartamentoID(idDept);
                            if(departamento==null){
                                System.out.println("Departamento no encontrado");
                            }else{
                                System.out.println(departamento);
                            }
                            break;
                        case 3:
                            departamento= new Departamento();
                            System.out.println("Introduce el nombre del departamento");
                            String nomDept=scanner.nextLine();
                            departamento.setNomDepto(nomDept);
                            departamentoService.guardarDepartmaento(departamento);
                            System.out.println("Departamento agregado");
                            System.out.println(departamento);

                            break;
                        case 4:
                            System.out.println("Escribe el id del departamento:");
                            idDept=scanner.nextInt();
                            scanner.nextLine();
                            departamento=departamentoService.encontrarDepartamentoID(idDept);
                            if(departamento==null){
                                System.out.println("Departamento no encontrado");
                            }else{
                                System.out.println(departamento);
                                System.out.println("Introduce el nuevo nombre del departamento");
                                nomDept=scanner.nextLine();
                                departamento.setNomDepto(nomDept);
                                System.out.println("Introduce el id de la sede");
                                int idSede=scanner.nextInt();
                                scanner.nextLine();
                                Sede sede = sedeService.encontrarSedeID(idSede);
                                departamentoService.cambiarSedeDepartamento(departamento,sede);
                                departamentoService.actualizarDepartamento(departamento);
                                System.out.println("Departamento actualizado");
                                System.out.println(departamento);

                            }
                            break;
                        case 5:
                            System.out.println("Escribe el id del departamento:");
                            idDept=scanner.nextInt();
                            scanner.nextLine();
                            departamento=departamentoService.encontrarDepartamentoID(idDept);
                            if(departamento==null){
                                System.out.println("Departamento no encontrado");
                            }else{
                                departamentoService.eliminarDepartametno(idDept);
                                System.out.println("Departamento eliminado");
                            }

                            break;
                        case 6:
                            System.out.println("Volviendo al menú principal");
                            break;
                        default:
                            System.out.println("Opción no válida");
                            break;
                    }
                    break;
                case 3:
                    System.out.println("1.Lista proyectos:");
                    System.out.println("2.Encontrar un proyecto por id");
                    System.out.println("3.Agregar un nuevo proyecto");
                    System.out.println("4.Actualizar un proyecto");
                    System.out.println("5.Eliminar un proyecto");
                    System.out.println("6.Volver al menú principal");
                    seleccion=scanner.nextInt();
                    scanner.nextLine();
                    switch (seleccion){
                        case 1://Lista
                            System.out.println("Lista de proyectos:**************");
                            proyectoService.listarProyectos().forEach(System.out::println);
                            System.out.println("Fin de la lista de proyectos:*********************");
                            break;
                        case 2://Encontrar id
                            System.out.println("Introduce el id del proyecto: ");
                            int idProy=scanner.nextInt();
                            scanner.nextLine();
                            Proyecto proyecto=proyectoService.encontrarProyectoID(idProy);
                            if(proyecto==null){
                                System.out.println("Proyecto no encontrada");
                            }else {
                                System.out.println(proyecto);
                            }
                            break;
                        case 3://Agregar un nuevo proyecto
                            System.out.println("Introduce el nombre del proyecto");
                            String nombProy=scanner.nextLine();
                           Proyecto proyecto1=new Proyecto();
                                    proyecto1.setNomProy(nombProy);
                            System.out.println("Introduce la fecha de inicio (YYYY-MM-DD): ");
                            String fInicioStr = scanner.nextLine();
                            proyecto1.setfInicio(Date.valueOf(fInicioStr));
                            proyectoService.guardaProyecto(proyecto1);
                            System.out.println("Proyecto agregado correctamente.");
                            break;

                        case 4://Actualizar proyecto
                            System.out.println("Introduce el id del proyecto: ");
                            idProy=scanner.nextInt();
                            scanner.nextLine();

                            proyecto=proyectoService.encontrarProyectoID(idProy);
                            if(proyecto==null){
                                System.out.println("Proyecto no encontrada");
                            }else {
                                System.out.println(proyecto);
                                System.out.println("Introduce el nuevo nombre de proyecto");
                                nombProy= scanner.nextLine();
                                proyecto.setNomProy(nombProy);
                                System.out.println("Introduce la nueva fecha de inicio (YYYY-MM-DD) o deja vacío para mantener la actual: ");
                                fInicioStr = scanner.nextLine();
                                if (!fInicioStr.isEmpty()) {
                                    proyecto.setfInicio(Date.valueOf(fInicioStr));
                                }

                                System.out.println("Introduce la nueva fecha de fin (YYYY-MM-DD) o deja vacío para mantener la actual: ");
                                String fFinStr = scanner.nextLine();
                                if (!fFinStr.isEmpty()) {
                                    proyecto.setfFin(Date.valueOf(fFinStr));
                                }
                                System.out.println("Introduce la id de la sede:");
                                int idSede=scanner.nextInt();
                                scanner.nextLine();

                                proyectoService.actualizarProyectoConSede(idProy,idSede);
                            }
                            break;

                        case 5://Eliminar proyecto

                            System.out.println("Introduce el id del proyecto eliminar: ");
                            idProy=scanner.nextInt();
                            scanner.nextLine();
                            proyecto=proyectoService.encontrarProyectoID(idProy);
                            if(proyecto==null){
                                System.out.println("Proyecto no encontrada");
                            }else{
                                proyectoService.eliminarProyecto(idProy);
                                System.out.println("Proyecto eliminado");
                            }
                            break;
                        case 6:
                            System.out.println("Volviendo al menú principal");
                            break;
                        default:
                            System.out.println("Opción no válida");
                            break;
                    }
                    break;
                case 4:
                    System.out.println("1.Listar sedes:");
                    System.out.println("2.Encontrar una sede por id");
                    System.out.println("3.Agregar una nueva sede");
                    System.out.println("4.Actualizar una sede");
                    System.out.println("5.Eliminar una sede");
                    System.out.println("6.Volver al menú principal");
                    seleccion=scanner.nextInt();
                    scanner.nextLine();
                    switch (seleccion){
                        case 1://Listar sede
                            System.out.println("Lista de sedes:**************");
                            sedeService.listarSedes().forEach(System.out::println);
                            System.out.println("Fin de la lista de sedes:*********************");
                            break;
                        case 2://Encontrar una  sede
                            System.out.println("Introduce el id de la sede: ");
                            int idSede=scanner.nextInt();
                            scanner.nextLine();
                            Sede sede=sedeService.encontrarSedeID(idSede);
                            if(sede==null){
                                System.out.println("Sede no encontrada");
                            }else {
                                System.out.println(sede);
                            }
                            break;
                        case 3://Agregar una nueva sede
                            System.out.println("Introduce el nombre de la sede");
                            String nomSede=scanner.nextLine();
                            Sede sede1 = new Sede();
                            sede1.setNomSede(nomSede);
                            sedeService.guardarSede(sede1);
                            System.out.println("Sede añadida");
                            System.out.println(sede1);
                            break;
                        case 4://Actualizar
                            System.out.println("Introduce el id de la sede:");
                            idSede=scanner.nextInt();
                            scanner.nextLine();
                            sede=sedeService.encontrarSedeID(idSede);
                            if(sede==null){
                                System.out.println("Sede no encontrada");
                            }else{
                                System.out.println("Introduce el nuevo nombre de la sede");
                                nomSede=scanner.nextLine();
                                sede.setNomSede(nomSede);
                                sedeService.actualizarSede(sede);

                            }
                            break;
                        case 5://Eliminar sede
                            System.out.println("Introduce el id de la sede a eliminar");
                            idSede=scanner.nextInt();
                            scanner.nextLine();
                            sede=sedeService.encontrarSedeID(idSede);
                            if(sede==null){
                                System.out.println("Sede no encontrada");
                            }else {
                                sedeService.eliminarSede(idSede);
                                System.out.println("Sede eliminada");
                            }
                            break;
                        case 6:
                            System.out.println("Volviendo al menú principal");
                            break;
                        default:
                            System.out.println("Opción no válida");
                            break;
                    }
                    break;
                case 5:
                    System.out.println("Saliendo del programa...");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida");
                    break;

            }

        }
       // em.close();
    }
}
