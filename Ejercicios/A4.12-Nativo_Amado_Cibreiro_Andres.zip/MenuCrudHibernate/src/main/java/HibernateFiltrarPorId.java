import entities.Departamento;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import util.JPAUtil;
import java.util.Scanner;

public class HibernateFiltrarPorId {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        EntityManager em = JPAUtil.getEntityManager();
        System.out.println("Introudce el id del departamento que quieres buscar:");
        int id = s.nextInt();
        Departamento departamento=em.find(Departamento.class,id);//El objeto queda guardado en cache, más eficiente si se vuelve a buscar usa el objeto en vez de volver a ejecutar la consulta
        System.out.println(departamento);
        em.close();


    }
}
