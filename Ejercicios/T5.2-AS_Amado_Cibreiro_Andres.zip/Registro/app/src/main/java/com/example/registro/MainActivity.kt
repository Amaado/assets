package com.example.registro

import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.registro.ui.theme.RegistroTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RegistroTheme {
                Registro()
            }
        }
    }
}

@Preview
@Composable
fun Registro() {
    val focusManager = LocalFocusManager.current
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)
        .pointerInput(Unit) {
            detectTapGestures(onTap = {
                focusManager.clearFocus()
            })
        }) {

        var nombre by remember { mutableStateOf("") }
        var selectedGender by remember { mutableStateOf<Gender?>(null) }
        var selectedHobby by remember { mutableStateOf<Hobby?>(null) }
        var showInfo by remember { mutableStateOf(false) }

        TextField(
            modifier = Modifier.padding(bottom = 16.dp),
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Ingresa tu nombre") },
        )
        Text(
            text = "Selecciona tu género:",
            modifier = Modifier.padding(bottom = 16.dp)
        )
        Row(
            modifier = Modifier.padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = selectedGender == Gender.Masculino,
                onClick = { selectedGender = Gender.Masculino }
            )
            Text(text = "Masculino", modifier = Modifier.padding(start = 8.dp))
            RadioButton(
                selected = selectedGender == Gender.Femenino,
                onClick = { selectedGender = Gender.Femenino }
            )
            Text(text = "Femenino", modifier = Modifier.padding(start = 8.dp))
        }
        Text(
            text = "Selecciona un hobbie:",
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Hobby.values().forEach { hobby ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                RadioButton(
                    selected = selectedHobby == hobby,
                    onClick = { selectedHobby = hobby }
                )
                Text(text = hobby.name, modifier = Modifier.padding(start = 8.dp))
            }
        }
        Button(onClick = {
            showInfo = true
        }) {
            Text(text = "Registrar")
        }
        if (showInfo) {

            Text(text = "Nombre: $nombre")
            Text(text = "Género: ${selectedGender?.name ?: "No seleccionado"}")
            Text(text = "Hobbie: ${selectedHobby?.name ?: "No seleccionado"}")
        }
    }
}

enum class Gender {
    Masculino, Femenino
}

enum class Hobby {
    Deportes, Videojuegos, Cine
}