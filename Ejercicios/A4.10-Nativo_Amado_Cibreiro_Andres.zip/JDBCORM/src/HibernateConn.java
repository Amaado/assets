import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.spi.ServiceException;

public class HibernateConn {
    private static SessionFactory sessionFactory;
    private static Session session;

    public static Session openSession() {

        try {
            sessionFactory = new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
            session = sessionFactory.openSession();

           return session;
        } catch (ServiceException e) {
            System.err.println("Error de comunicación con la base de datos: " + e.getMessage());
            e.printStackTrace();
        } catch (HibernateException e) {
            System.err.println("Error de Hibernate: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error desconocido: " + e.getMessage());
            e.printStackTrace();
        }
        return session;
    }

    public static void closeSession() {
        if (session != null && session.isOpen()) {
            session.close();
        }
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }

}
