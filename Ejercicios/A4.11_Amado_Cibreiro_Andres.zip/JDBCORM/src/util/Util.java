package util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Util {
    private static EntityManagerFactory buildEntityManagerFactory(){
        return Persistence.createEntityManagerFactory("");
    }
}
