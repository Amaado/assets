package entities;

import java.io.Serializable;
import java.util.Objects;

public class ProyectoSedePK implements Serializable {
    private int idProy;  // Debe coincidir con el tipo de Proyecto.idProy (int)
    private int idSede;  // Asume que Sede.idSede es int

    // Getters, Setters, equals, hashCode
    public int getIdProy() { return idProy; }
    public void setIdProy(int idProy) { this.idProy = idProy; }

    public int getIdSede() { return idSede; }
    public void setIdSede(int idSede) { this.idSede = idSede; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProyectoSedePK that = (ProyectoSedePK) o;
        return idProy == that.idProy && idSede == that.idSede;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProy, idSede);
    }
}