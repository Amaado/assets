package entities;

import javax.persistence.*;
import java.io.Serializable;
@Entity
@Table(name="sede")
public class Sede implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_sede", unique = true, nullable = false)
    private int idSede;
    @Column(name="nom_sede",nullable = false,length=20)
    private String nomSede;

    public Sede(){}


    public int getIdSede() {
        return idSede;
    }

    public void setIdSede(int idSede) {
        this.idSede = idSede;
    }

    public String getNomSede() {
        return nomSede;
    }

    public void setNomSede(String nomSede) {
        this.nomSede = nomSede;
    }
}
