package entities;

import org.hibernate.Session;

import javax.persistence.*;
import java.io.Serializable;
@Entity
@Table(name="empleado")
public class Empleado implements Serializable {
    @Id
    @Column(name="dni",length = 9,nullable = false)
    private String dni;
    @Column(name="nom_emp",length = 40,nullable = false)
    private String nomEmp;
    @ManyToOne
    @JoinColumn(name = "id_depto", nullable = false)
    private Departamento idDepto;

    public Empleado(){}

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNomEmp() {
        return nomEmp;
    }

    public void setNomEmp(String nomEmp) {
        this.nomEmp = nomEmp;
    }

    public Departamento getIdDepto() {
        return idDepto;
    }

    public void setIdDepto(Departamento idDepto) {
        this.idDepto = idDepto;
    }

    /*public static void addEmpleado(Session session,String dni, String nomEmp, Departamento nDepartamento){
        System.out.println("Nuevo empleado:");
        Empleado empleado=new Empleado();
        empleado.setDni();
        empleado.setNomEmp(nomEmp);
        empleado.setIdDepto(nDepartamento);
        session.save(empleado);

    }*/
}
