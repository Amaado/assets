package com.example.menucontextuallista

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PantallaMenuContextual()
        }
    }
}

@Composable
fun PantallaMenuContextual() {
    val listaOpciones = listOf("Opción de menú A", "Opción de menú B", "Opción de menú C", "Opción de menú D", "Opción de menú E")
    var opcionSeleccionada by remember { mutableStateOf("Selecciona una opción") }
    var menuContextualAbierto by remember { mutableStateOf(false) }
    var tituloMenu by remember { mutableStateOf("") }
    var opcionesSubMenu by remember { mutableStateOf(listOf<String>()) }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(Color(167, 216, 230)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Ejemplo de menú contextual",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        Spacer(modifier = Modifier.height(35.dp))

        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            items(listaOpciones) { item ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .background(Color(167, 216, 230))
                        .clickable {
                            tituloMenu = item
                            opcionesSubMenu = listOf("Opción 1 de $item", "Opción 2 de $item")
                            menuContextualAbierto = true
                        }
                        .padding(16.dp)
                ) {
                    Text(
                        text = item,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Text(
            text = opcionSeleccionada,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 16.dp)
        )
    }

    if (menuContextualAbierto) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = tituloMenu,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    opcionesSubMenu.forEach { opcion ->
                        TextButton(
                            onClick = {
                                opcionSeleccionada = opcion
                                menuContextualAbierto = false
                            }
                        ) {
                            Text(opcion)
                        }
                    }

                }
            }
        }
    }
}
