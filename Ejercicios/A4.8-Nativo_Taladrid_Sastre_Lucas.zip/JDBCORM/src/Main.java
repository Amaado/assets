

import entities.Departamento;
import entities.Empleado;
import entities.Sede;
import net.sf.ehcache.hibernate.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {

    public static void main(String[] args) {
        Transaction t= null;
        try( Session s= HibernateConn.openSession()){
            t=s.beginTransaction();
            Sede sede= new Sede();
            sede.setNomSede("Málaga");
            s.save(sede);

            Departamento departamento = new Departamento();
            departamento.setNomDepto("INVESTIGACIÓN Y DESRROLO");
            departamento.setIdSede(sede);
            s.save(departamento);

            Departamento departamento1 = new Departamento();
            departamento1.setNomDepto("I+D");
            departamento1.setIdSede(sede);
            s.save(departamento1);

            Empleado empleado = new Empleado();
            empleado.setDni("56789012G");
            empleado.setNomEmp("SAMPER");
            empleado.setIdDepto(departamento);
            s.save(empleado);

            Empleado empleado1 = new Empleado();
            empleado1.setDni("56789088B");
            empleado1.setNomEmp("Manolo");
            empleado1.setIdDepto(departamento1);
            s.save(empleado1);
            t.commit();

            System.out.println("Commit exitoso");
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("No se ha podido ejecutrar el commit");
            if(t != null){
                t.rollback();
            }
        }



    }

}