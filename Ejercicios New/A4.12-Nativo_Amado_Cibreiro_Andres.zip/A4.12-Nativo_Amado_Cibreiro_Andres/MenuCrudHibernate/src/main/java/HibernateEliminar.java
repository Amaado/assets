import entities.Sede;
import jakarta.persistence.EntityManager;
import util.JPAUtil;

import java.util.Scanner;

public class HibernateEliminar {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el id de la sede a eliminar: ");
        int id = scanner.nextInt();
        EntityManager em = JPAUtil.getEntityManager();


        try{

            em.getTransaction().begin();
            Sede sede = em.find(Sede.class,id);//Para que funcione el remove el objeto se debe de crear así, con la búsqueda
            em.remove(sede);
            em.getTransaction().commit();
            System.out.println("Sede eliminada con éxtio");

        }catch (Exception e){
            em.getTransaction().rollback();
            e.printStackTrace();
        }finally {
            em.close();

        }
    }
}
