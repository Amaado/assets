package repositories;

import jakarta.persistence.EntityManager;

import java.util.List;

public class JPACrudRepositoy<T,ID> implements CrudRepository<T,ID>{

    private EntityManager em;
    private final Class<T> entityClass;

    public JPACrudRepositoy(EntityManager em, Class<T> entityClass) {
        this.em = em;
        this.entityClass=entityClass;
    }

    @Override
    public List<T> listar() {
        return em.createQuery("FROM "+entityClass.getSimpleName(),entityClass).getResultList();
    }

    @Override
    public T porId(ID id) {
        return em.find(entityClass,id);
    }

    @Override
    public void guardar(T t) {
        em.persist(t);

    }
    public void actualizar(T t){
        em.merge(t);
    }

    @Override
    public void eliminar(ID id) {
        T entidad = porId(id);
        if (entidad != null) {
            em.remove(entidad);
        }
    }

}
