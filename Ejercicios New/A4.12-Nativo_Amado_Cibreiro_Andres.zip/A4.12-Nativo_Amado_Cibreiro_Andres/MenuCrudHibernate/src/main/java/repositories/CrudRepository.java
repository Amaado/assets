package repositories;



import java.util.List;

public interface CrudRepository<T,ID> {
    List<T>listar();
    T porId(ID id);
    void guardar(T t);
    void actualizar(T t);
    void eliminar(ID id);


}
