import entities.Empleado;
import jakarta.persistence.EntityManager;
import util.JPAUtil;

import java.util.List;

public class HibernateListar {
    public static void main(String[] args) {

        EntityManager em= JPAUtil.getEntityManager();
        List<Empleado> empleadoList=em.createQuery("SELECT e FROM Empleado e",Empleado.class).getResultList();
        empleadoList.forEach(System.out::println);
        em.close();



    }
}
