import entities.Empleado;
import entities.Sede;
import jakarta.persistence.EntityManager;
import util.JPAUtil;

import java.util.Scanner;

public class HibernateCrear {
    public static void main(String[] args) {

        EntityManager em= JPAUtil.getEntityManager();
        try{
            Scanner scanner = new Scanner(System.in);
            System.out.println("Introduce el nombre de la sede:");
            String nombre=scanner.nextLine();

            em.getTransaction().begin();
            Sede sede = new Sede();
            sede.setNomSede(nombre);
            em.persist(sede);
            em.getTransaction().commit();

            System.out.println("La sede se ha guardado con el id: "+sede.getIdSede());
            sede=em.find(Sede.class,sede.getIdSede());
            System.out.println(sede);

        }catch (Exception e){
            em.getTransaction().rollback();
            e.printStackTrace();
        }finally {
            em.close();
        }
    }
}
