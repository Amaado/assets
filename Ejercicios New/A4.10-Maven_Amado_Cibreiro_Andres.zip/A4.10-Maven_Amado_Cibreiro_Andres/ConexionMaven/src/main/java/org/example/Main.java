package org.example;

import entities.Departamento;
import entities.Empleado;
import entities.Proyecto;
import entities.Sede;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Main {
    private static SessionFactory sessionFactory;

    public static void main(String[] args) {
        Transaction t = null;
        try {
            // Configuración de Hibernate
            sessionFactory = new Configuration()
                    .configure()
                    .addAnnotatedClass(Empleado.class)
                    .addAnnotatedClass(Departamento.class)
                    .addAnnotatedClass(Sede.class)
                    .addAnnotatedClass(Proyecto.class)
                    .buildSessionFactory();

            // Abre una sesión
            try (Session session = sessionFactory.openSession()) {
                t = session.beginTransaction(); // Iniciar la transacción correctamente
                //Inserción de empleados
              /*  Departamento departamento = (Departamento) session.createQuery("FROM Departamento d WHERE idDepto=:idDepto", Departamento.class).setParameter("idDepto",4).getSingleResult();
                Empleado empleado = new Empleado();
                empleado.setDni("56789012A");
                empleado.setNomEmp("Ana María");
                empleado.setIdDepto(departamento);
                session.save(empleado);

                Empleado empleado1 = new Empleado();
                empleado1.setDni("56789088C");
                empleado1.setNomEmp("Manolo Laranxeira");
                empleado1.setIdDepto(departamento);
                session.save(empleado1);
                Empleado empleado2 = new Empleado();
                empleado2.setDni("56789012S");
                empleado2.setNomEmp("Carlos Vispo");
                empleado2.setIdDepto(departamento);
                session.save(empleado2);
                Empleado empleado5 = new Empleado();
                empleado5.setDni("56789012P");
                empleado5.setNomEmp("Jose María");
                empleado5.setIdDepto(session.find(Departamento.class,4)); //Interesante tener en cuenta que no es necesario la consulta y se puede usar el método find mediante la session
                session.save(empleado5);

                Empleado empleado3 = new Empleado();
                empleado3.setDni("56789088H");
                empleado3.setNomEmp("Manolo Gonzalez");
                empleado3.setIdDepto(departamento);
                session.save(empleado3);
                Empleado empleado4 = new Empleado();
                empleado4.setDni("56789012I");
                empleado4.setNomEmp("Pablo Botana");
                empleado4.setIdDepto(departamento);
                session.save(empleado4);

*/
                //Consulta para confirmar que tenemos los empleados recién creados, todos pertenencen al departamento 4, por lo tanto vamos a pedir los empleados con departamento 4

                /*String hqlEmpDep4="FROM Empleado e WHERE e.idDepto.idDepto=:idDepto";
                List<Empleado> empleadoList=session.createQuery(hqlEmpDep4, Empleado.class).setParameter("idDepto",4).getResultList();
                System.out.println("Empleado con departamento 4");
                for(Empleado empleado: empleadoList){
                    System.out.println(empleado.getNomEmp()+"--"+empleado.getDni());
                }*/

                //Inserción de dos categoría de empleados
              /*  EmpleadoDatosProf empleadoDatosProf = new EmpleadoDatosProf();
                Empleado empleado=session.find(Empleado.class, "56789012I");
                empleadoDatosProf.setDni(empleado.getDni());
                empleadoDatosProf.setCategoria("C4");
                empleadoDatosProf.setSueldoBrutoAnual(BigDecimal.valueOf(40000.00));
                session.save(empleadoDatosProf);*/

               /* EmpleadoDatosProf empleadoDatosProf1 = new EmpleadoDatosProf();
                Empleado empleado1=session.find(Empleado.class, "56789088H");
                empleadoDatosProf1.setDni(empleado1.getDni());
                empleadoDatosProf1.setCategoria("A4");
                empleadoDatosProf1.setSueldoBrutoAnual(BigDecimal.valueOf(50000.00));
                session.save(empleadoDatosProf1);*/

                //Consulta para confirmar que se hizo el insert
                /*String hqlEmpDatProf="FROM EmpleadoDatosProf e";
                List<EmpleadoDatosProf>empleadoDatosProfList=session.createQuery(hqlEmpDatProf,EmpleadoDatosProf.class).getResultList();
                for(EmpleadoDatosProf empleadoDatosProf:empleadoDatosProfList){
                    System.out.println(empleadoDatosProf.getDni()+"--"+empleadoDatosProf.getCategoria()+"--"+empleadoDatosProf.getSueldoBrutoAnual());
                }*/




                //Inserción de proyectos
                //Importante al insertar la fecha, ya que estamos creando una fecha de java y vamos a necesitar una fecha sql, por lo tanto la conversión es de vital importancia
                /*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date fechaInicio = sdf.parse("2025-01-01");
                Date fechaInicio1 = sdf.parse("2023-01-01");
                Date fechaInicio2 = sdf.parse("2025-02-01");

                Proyecto proyecto = new Proyecto();
                proyecto.setIdProy(7);
                proyecto.setfInicio(new java.sql.Date(fechaInicio.getTime()));
                proyecto.setNomProy("Proyecto Charle");
                session.save(proyecto);

                Proyecto proyecto1 = new Proyecto();
                proyecto1.setIdProy(8);
                proyecto1.setfInicio(new java.sql.Date(fechaInicio1.getTime()));
                proyecto1.setNomProy("Proyecto Bravo");
                session.save(proyecto1);

                Proyecto proyecto2 = new Proyecto();
                proyecto2.setIdProy(9);
                proyecto2.setfInicio(new java.sql.Date(fechaInicio2.getTime()));
                proyecto2.setNomProy("Proyecto Fox");
                session.save(proyecto2);*/

                //Consulta de los proyectos

               String hqlPro ="From Proyecto";
                List<Proyecto> proyectoList=session.createQuery(hqlPro,Proyecto.class)
                        .getResultList();
                System.out.println("Proyectos de toda la empresa");
                for(Proyecto proyecto: proyectoList){
                    System.out.println(proyecto.getNomProy()+"---"+proyecto.getIdProy());
                }





                //Consulta para ver todos los empleados de la empresa
                /*String hql = "FROM Empleado";
                List<Empleado> empleados = session.createQuery(hql, Empleado.class)
                        .getResultList();
                System.out.println("Empleados de toda la empresa");
                for (Empleado emp : empleados) {
                    System.out.println(emp.getNomEmp() + " - " + emp.getDni());
                }
                System.out.println("Fin de la lista de los empleados");*/
                //Consulta para ver todos los departamentos
               /* String hqlDept ="From Departamento";
                List<Departamento> departamentos=session.createQuery(hqlDept,Departamento.class)
                                .getResultList();
                System.out.println("Departamentos de toda la empresa");
                for(Departamento dept: departamentos){
                    System.out.println(dept.getNomDepto()+"-"+dept.getIdDepto());
                }*/
                //Consulta de sedes para obtener solo el nombre
               /* String hqlSede="SELECT s.nomSede FROM Sede s";
                List<String> nombresSedes=session.createQuery(hqlSede,String.class).getResultList();
                System.out.println("Lista de nombres de sedes:");
                for (String nombre : nombresSedes) {
                    System.out.println(nombre);
                }*/

                //Consutla de empleados para obtener solo el nombre
               /* String hqlEmps="SELECT e.nomEmp FROM Empleado e";
                List<String> nombresEmpleados=session.createQuery(hqlEmps,String.class).getResultList();
                System.out.println("Lista de nombres de empleados:");
                for (String nombre : nombresEmpleados) {
                    System.out.println(nombre);
                }*/
                //Consutla de proyectos para obtener solo el nombre
               /* String hqlProy="SELECT p.nomProy FROM Proyecto p";
                List<String> nombresProyectos=session.createQuery(hqlProy,String.class).getResultList();
                System.out.println("Lista de nombres de proyectos:");
                for (String nombre : nombresProyectos) {
                    System.out.println(nombre);
                }*/

                //Consulta  empleados, dni = X (por definir)
             /*   String hqlEmpCond="FROM Empleado e WHERE e.dni=:dni";
                List<Empleado> empleadoList =session.createQuery(hqlEmpCond, Empleado.class)
                        .setParameter("dni","34567890C")
                        .getResultList();

                System.out.println("Empleado cuyo dni es: 34567890C");
                for (Empleado empleado : empleadoList) {
                    System.out.println(empleado.getNomEmp()+"-"+empleado.getDni());
                }*/
                //Consulta proyectos, fecha_inicio > X (por definir)
               /* SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date fechaInicio = sdf.parse("2025-01-01");
                String hqlProyectoCOnd="FROM Proyecto p WHERE p.fInicio>:fInicio";
                List<Proyecto> proyectoList = session.createQuery(hqlProyectoCOnd, Proyecto.class)
                                .setParameter("fInicio",fechaInicio)
                                        .getResultList();
                System.out.println("Proyectos con fecha de inicio: 2025-01-01");
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy());
                }*/
                //Consulta proyectos, fecha_fin < X (por definir)
               /* SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date fechaFin = sdf.parse("2026-01-01");
                String hqlProyectoCOnd="FROM Proyecto p WHERE p.fFin<:fFin";
                List<Proyecto> proyectoList = session.createQuery(hqlProyectoCOnd, Proyecto.class)
                                .setParameter("fFin",fechaFin)
                                        .getResultList();
                System.out.println("Proyectos con fecha de fin menor: 2026-01-01");
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy());
                }*/
                //Uso de alias en tabla sede
               /* String hqlAlSede="FROM Sede s";
                List<Sede> sedes=session.createQuery(hqlAlSede,Sede.class).getResultList();
                System.out.println("Sedes");
                for(Sede sede :sedes){
                    System.out.println(sede.getNomSede()+"-"+sede.getIdSede());
                }
                System.out.println("Fin de las sedes");*/
                //Uso de alias en tabla departamento
               /* String hqlAlDepartamento="FROM Departamento d";
                List<Departamento> departamentos = session.createQuery(hqlAlDepartamento,Departamento.class).getResultList();
                System.out.println("Departamentos");
                for(Departamento departamento:departamentos){
                    System.out.println(departamento.getNomDepto()+"-"+departamento.getIdDepto()+"-"+departamento.getIdSede().getIdSede());
                }
                System.out.println("Fin de los departamentos");*/
                //Ordenar sedes por nombre
                /*String hqlSedeOrden="FROM Sede s GROUP BY s.nomSede";
                List<Sede> sedes =session.createQuery(hqlSedeOrden,Sede.class).getResultList();
                for(Sede sede:sedes){
                    System.out.println(sede.getNomSede()+"-"+sede.getIdSede());
                }*/
                //Ordenar departamentos por sede
                /*String hqlDepartamentoOrden="FROM Departamento d GROUP BY d.idSede";
                List<Departamento> departamentos =session.createQuery(hqlDepartamentoOrden,Departamento.class).getResultList();
                for(Departamento departamento:departamentos){
                    System.out.println(departamento.getNomDepto()+"-"+departamento.getIdSede().getIdSede()+"-"+departamento.getIdDepto());
                }*/
                //Ordenar empleados por categoría
              /*  String hqlEmpleadoOrden="SELECT e FROM Empleado e JOIN EmpleadoDatosProf edp ON e.dni=edp.dni GROUP BY edp.categoria";
                List<Empleado> empleados =session.createQuery(hqlEmpleadoOrden,Empleado.class).getResultList();
                for(Empleado empleado:empleados){
                    System.out.println(empleado.getNomEmp()+"-"+empleado.getDni());
                }*/
                //Ordenar proyectos por fecha de inicio
                /*String hqlProyectoOrdenInicio="FROM Proyecto p GROUP BY p.fInicio";
                List<Proyecto> proyectoList=session.createQuery(hqlProyectoOrdenInicio, Proyecto.class).getResultList();
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy()+"-"+proyecto.getfInicio()+"-"+proyecto.getfFin());
                }*/
                //Ordenar proyectos por fecha de fin
               /* String hqlProyectoOrdenFin="FROM Proyecto p GROUP BY p.fFin";
                List<Proyecto> proyectoList=session.createQuery(hqlProyectoOrdenFin, Proyecto.class).getResultList();
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy()+"-"+proyecto.getfInicio()+"-"+proyecto.getfFin());
                }*/





                t.commit(); // Hacer commit correctamente
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("No se ha podido ejecutar el commit");
                if (t != null) {
                    t.rollback(); // Se ejecutará correctamente si hay un error
                }
            }
        } catch (Throwable ex) {
            System.err.println("Error al inicializar SessionFactory: " + ex);
            throw new ExceptionInInitializerError(ex);
        } finally {
            if (sessionFactory != null) {
                sessionFactory.close();
            }
        }
    }
}
/*


                Sede sede= new Sede();
                sede.setNomSede("Málaga");
                session.save(sede);

                Departamento departamento = new Departamento();
                departamento.setNomDepto("INVESTIGACIÓN Y DESRROLO");
                departamento.setIdSede(sede);
                session.save(departamento.getIdDepto());

                Departamento departamento1 = new Departamento();
                departamento1.setNomDepto("I+D");
                departamento1.setIdSede(sede);
                session.save(departamento1);

                Empleado empleado = new Empleado();
                empleado.setDni("56789012X");
                empleado.setNomEmp("SAMPER");
                empleado.setIdDepto(departamento);
                session.save(empleado);

                Empleado empleado1 = new Empleado();
                empleado1.setDni("56789088X");
                empleado1.setNomEmp("Manolo");
                empleado1.setIdDepto(departamento1);
                session.save(empleado1);

 */
