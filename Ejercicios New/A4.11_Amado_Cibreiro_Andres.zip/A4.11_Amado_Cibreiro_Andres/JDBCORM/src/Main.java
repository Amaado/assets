

import com.mysql.cj.x.protobuf.MysqlxCrud;
import entities.*;
import net.sf.ehcache.hibernate.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import javax.persistence.TypedQuery;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    private static SessionFactory sessionFactory;
    public static void main(String[] args) {
        Transaction t = null;
        try {
            // Configuración de Hibernate
            sessionFactory = new Configuration()
                    .configure()
                    .addAnnotatedClass(Empleado.class)
                    .addAnnotatedClass(Departamento.class)
                    .addAnnotatedClass(Sede.class)
                    .addAnnotatedClass(Proyecto.class)
                    .buildSessionFactory();

            // Abre una sesión
            try (Session session = sessionFactory.openSession()) {
                t = session.beginTransaction(); // Iniciar la transacción correctamente
                //CONSULTAS HQL





//Consulta para ver todos los empleados de la empresa
               /* String hql = "FROM Empleado";
                List<Empleado> empleados = session.createQuery(hql, Empleado.class)
                        .getResultList();
                System.out.println("Empleados de toda la empresa");
                for (Empleado emp : empleados) {
                    System.out.println(emp.getNomEmp() + " - " + emp.getDni());
                }
                System.out.println("Fin de la lista de los empleados");*/
//Consulta para ver todos los departamentos
               /* String hqlDept ="From Departamento";
                List<Departamento> departamentos=session.createQuery(hqlDept,Departamento.class)
                                .getResultList();
                System.out.println("Departamentos de toda la empresa");
                for(Departamento dept: departamentos){
                    System.out.println(dept.getNomDepto()+"-"+dept.getIdDepto());
                }*/
//Consulta de sedes para obtener solo el nombre
                /*String hqlSede="SELECT s.nomSede FROM Sede s";
                List<String> nombresSedes=session.createQuery(hqlSede,String.class).getResultList();
                System.out.println("Lista de nombres de sedes:");
                for (String nombre : nombresSedes) {
                    System.out.println(nombre);
                }*/

//Consutla de empleados para obtener solo el nombre
               /* String hqlEmps="SELECT e.nomEmp FROM Empleado e";
                List<String> nombresEmpleados=session.createQuery(hqlEmps,String.class).getResultList();
                System.out.println("Lista de nombres de empleados:");
                for (String nombre : nombresEmpleados) {
                    System.out.println(nombre);
                }*/
//Consutla de proyectos para obtener solo el nombre
               /* String hqlProy="SELECT p.nomProy FROM Proyecto p";
                List<String> nombresProyectos=session.createQuery(hqlProy,String.class).getResultList();
                System.out.println("Lista de nombres de proyectos:");
                for (String nombre : nombresProyectos) {
                    System.out.println(nombre);
                }*/

//Consulta  empleados, dni = X (por definir)
               /*String hqlEmpCond="FROM Empleado e WHERE e.dni=:dni";
                List<Empleado> empleadoList =session.createQuery(hqlEmpCond, Empleado.class)
                        .setParameter("dni","34567890C")
                        .getResultList();

                System.out.println("Empleado cuyo dni es: 34567890C");
                for (Empleado empleado : empleadoList) {
                    System.out.println(empleado.getNomEmp()+"-"+empleado.getDni());
                }*/
//Consulta proyectos, fecha_inicio > X (por definir)
              /*  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date fechaInicio = sdf.parse("2025-01-01");
                String hqlProyectoCOnd="FROM Proyecto p WHERE p.fInicio>:fInicio";
                List<Proyecto> proyectoList = session.createQuery(hqlProyectoCOnd, Proyecto.class)
                                .setParameter("fInicio",fechaInicio)
                                        .getResultList();
                System.out.println("Proyectos con fecha de inicio: 2025-01-01");
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy());
                }*/
//Consulta proyectos, fecha_fin < X (por definir)
              /*  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date fechaFin = sdf.parse("2026-01-01");
                String hqlProyectoCOnd="FROM Proyecto p WHERE p.fFin<:fFin";
                List<Proyecto> proyectoList = session.createQuery(hqlProyectoCOnd, Proyecto.class)
                                .setParameter("fFin",fechaFin)
                                        .getResultList();
                System.out.println("Proyectos con fecha de fin menor: 2026-01-01");
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy());
                }*/
//Uso de alias en tabla sede
               /* String hqlAlSede="FROM Sede s";
                List<Sede> sedes=session.createQuery(hqlAlSede,Sede.class).getResultList();
                System.out.println("Sedes");
                for(Sede sede :sedes){
                    System.out.println(sede.getNomSede()+"-"+sede.getIdSede());
                }
                System.out.println("Fin de las sedes");*/
//Uso de alias en tabla departamento
               /* String hqlAlDepartamento="FROM Departamento d";
                List<Departamento> departamentos = session.createQuery(hqlAlDepartamento,Departamento.class).getResultList();
                System.out.println("Departamentos");
                for(Departamento departamento:departamentos){
                    System.out.println(departamento.getNomDepto()+"-"+departamento.getIdDepto()+"-"+departamento.getIdSede().getIdSede());
                }
                System.out.println("Fin de los departamentos");*/
//Ordenar sedes por nombre
                /*String hqlSedeOrden="FROM Sede s GROUP BY s.nomSede";
                List<Sede> sedes =session.createQuery(hqlSedeOrden,Sede.class).getResultList();
                for(Sede sede:sedes){
                    System.out.println(sede.getNomSede()+"-"+sede.getIdSede());
                }*/
//Ordenar departamentos por sede
                /*String hqlDepartamentoOrden="FROM Departamento d GROUP BY d.idSede";
                List<Departamento> departamentos =session.createQuery(hqlDepartamentoOrden,Departamento.class).getResultList();
                for(Departamento departamento:departamentos){
                    System.out.println(departamento.getNomDepto()+"-"+departamento.getIdSede().getIdSede()+"-"+departamento.getIdDepto());
                }*/
//Ordenar empleados por categoría
              /*  String hqlEmpleadoOrden="SELECT e FROM Empleado e JOIN EmpleadoDatosProf edp ON e.dni=edp.dni GROUP BY edp.categoria";
                List<Empleado> empleados =session.createQuery(hqlEmpleadoOrden,Empleado.class).getResultList();
                for(Empleado empleado:empleados){
                    System.out.println(empleado.getNomEmp()+"-"+empleado.getDni());
                }*/
//Ordenar proyectos por fecha de inicio
              /*  String hqlProyectoOrdenInicio="FROM Proyecto p GROUP BY p.fInicio";
                List<Proyecto> proyectoList=session.createQuery(hqlProyectoOrdenInicio, Proyecto.class).getResultList();
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy()+"-"+proyecto.getfInicio()+"-"+proyecto.getfFin());
                }*/
//Ordenar proyectos por fecha de fin
                /*String hqlProyectoOrdenFin="FROM Proyecto p GROUP BY p.fFin";
                List<Proyecto> proyectoList=session.createQuery(hqlProyectoOrdenFin, Proyecto.class).getResultList();
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy()+"-"+proyecto.getfInicio()+"-"+proyecto.getfFin());
                }*/
//Uso de like
//listar los empleados cuyo nombre empieza por B (se puede elegir otra letra)
                /*String hqlEmpLike="FROM Empleado WHERE nomEmp LIKE 'M%'";
                List<Empleado> empleados =session.createQuery(hqlEmpLike,Empleado.class).getResultList();
                for(Empleado empleado:empleados){
                    System.out.println(empleado.getNomEmp()+"-"+empleado.getDni());
                }*/
//listas los proyectos cuyo nombre empieza por A (se puede elegir otra letra)
                /*String halProyLike="FROM Proyecto where nomProy LIKE 'P%'";
                List<Proyecto> proyectoList = session.createQuery(halProyLike, Proyecto.class).getResultList();
                for (Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy());
                }*/
//Contrar registros
//Contrar empleado
                /*String hqlContarEmp="SELECT COUNT(e) FROM Empleado e";
                Long cuenta=session.createQuery(hqlContarEmp,Long.class).getSingleResult();
                System.out.println("La cuenta de todos los empleado es:"+cuenta);
*/
//Contrar proyectos
               /*String hqlContarProy="SELECT COUNT(p) FROM Proyecto p";
                Long cuenta=session.createQuery(hqlContarProy,Long.class).getSingleResult();
                System.out.println("La cuenta de todos los proyectos es:"+cuenta);*/

//Contar sedes
                /*String hqlContarSede="SELECT COUNT(s) FROM Sede s";
                Long cuenta=session.createQuery(hqlContarSede,Long.class).getSingleResult();
                System.out.println("La cuenta de todos los sede es:"+cuenta);*/

//Agrupar resultados
//número total de empleados en un departamento x
               /* String hqlCountEmpDep = "SELECT COUNT(e) FROM Empleado e WHERE e.idDepto.idDepto = :idDepto";
                int id = 1;
                Long cuenta = session.createQuery(hqlCountEmpDep,Long.class).setParameter("idDepto",id).getSingleResult();
                System.out.println("La cantidad de empleados que se encuentran en el Deptarmante con id: "+id+ " son: "+cuenta);*/
//número total de proyectos en una sede x
                /*String hqlCountProySede = "SELECT COUNT(ps.idProy) FROM ProyectoSede ps WHERE ps.idSede.idSede = :idSede";
                int id = 3;
                Long cuenta = session.createQuery(hqlCountProySede,Long.class).setParameter("idSede",id).getSingleResult();
                System.out.println("La cantidad de proyectos que tiene la sede con id: "+id+ " son: "+cuenta);*/

//número total de departamentos en una sede x
              /*  String hqlCountDepSede="SELECT COUNT(d) FROM Departamento d WHERE d.idSede.idSede=:idSede";
                int id=1;
                Long cuenta =session.createQuery(hqlCountDepSede, Long.class).setParameter("idSede",id).getSingleResult();
                System.out.println("La cantidad de departamentos que tiene la sede con id: "+id+" son: "+cuenta);*/

//Filtar grupos having
//departamentos con más de (X) empleados, X (por definir)
         /*       int n = 1;
                String hqlDepMoreEmp =
                        "SELECT d FROM Departamento d " +
                                "JOIN Empleado e ON e.idDepto.idDepto = d.idDepto " +
                                "GROUP BY d " +
                                "HAVING COUNT(e) > :n";

                List<Departamento> departamentos = session.createQuery(hqlDepMoreEmp, Departamento.class)
                        .setParameter("n",(long) n)  //IMportante convertir a long, de otra forma falal
                        .getResultList();

                System.out.println("Los departamentos con más de " + n + " empleados son:");
                for (Departamento departamento : departamentos) {
                    System.out.println(departamento.getNomDepto() + " - " + departamento.getIdDepto());
                }*/

//proyectos con menos de (X) sedes, X (por definir)
              /*  int n=2;
                String hqlProyLessSedes =
                        "SELECT p FROM Proyecto p " +
                                "JOIN ProyectoSede ps ON ps.idProy = p " +
                                "GROUP BY p.idProy " +
                                "HAVING COUNT(ps.idSede) < :n";
                List<Proyecto> proyectoList=session.createQuery(hqlProyLessSedes, Proyecto.class).setParameter("n",(long)n).getResultList();
                System.out.println("Los proyectos con menos de "+n+" sedes implicadas son:");
                for(Proyecto proyecto:proyectoList){
                    System.out.println(proyecto.getNomProy()+"-"+proyecto.getIdProy());
                }*/


//departamentos con un número igual (X) sedes, X (por definir)
             /*   int n = 1;

                String hqlDepSameSedeWithCount =
                        "SELECT d.idSede, COUNT(d) " +
                                "FROM Departamento d " +
                                "GROUP BY d.idSede " +
                                "HAVING d.idSede.idSede = :n AND COUNT(d) > :n";

                List<Object[]> results = session.createQuery(hqlDepSameSedeWithCount)
                        .setParameter("n", n)
                        .getResultList();

                System.out.println("Departamentos con sede igual a " + n + " y más de " + n + " departamentos:");
                for (Object[] result : results) {
                    Sede sede = (Sede) result[0]; // El primer elemento es el idSede
                    Long count = (Long) result[1]; // El segundo elemento es el count de departamentos
                    System.out.println("Sede: " + sede.getIdSede() + " - Total de departamentos: " + count);
                }*/

//Proyección de múltiples columnas, obtener

// fecha_inicio y fecha_fin de proyectos
                /*String hqlProyectoColumns="FROM Proyecto p";
                List<Proyecto> proyectoList=session.createQuery(hqlProyectoColumns, Proyecto.class).getResultList();
                for (Proyecto proyecto:proyectoList){
                    System.out.println("Fecha inicio: "+proyecto.getfInicio()+" Fecha final: "+proyecto.getfFin()+" Nom proyecto: "+proyecto.getNomProy());
                }*/
// dni y nombre de empleado
                /*String hqlEmpCol="FROM Empleado e";
                List<Empleado>empleados=session.createQuery(hqlEmpCol,Empleado.class).getResultList();
                for (Empleado empleado:empleados){
                    System.out.println("DNI: "+empleado.getDni()+" Nombre: "+empleado.getNomEmp());
                }*/

//categoría y sueldo empleado
                /*String hqlEmpDProfCol="FROM EmpleadoDatosProf edp";
                List<EmpleadoDatosProf> empleadoDatosProfList= session.createQuery(hqlEmpDProfCol,EmpleadoDatosProf.class).getResultList();
                for(EmpleadoDatosProf empleadoDatosProf:empleadoDatosProfList){
                    System.out.println("Categoría: "+empleadoDatosProf.getCategoria()+" Sueldo: "+empleadoDatosProf.getSueldoBrutoAnual());
                }*/

//Join explícito (LEFT JOIN)
// Lista de empleados junto con su departamento, incluyendo aquellos que no tienen departamento
               /* String hql = "SELECT e.dni, e.nomEmp, d.nomDepto FROM Empleado e LEFT JOIN e.idDepto d";
                Query<Object[]> query = session.createQuery(hql);

                List<Object[]> results = query.getResultList();
                for (Object[] result : results) {
                    String dni=(String)result[0];
                    String nombre = (String) result[1];
                    String departamento=(String)result[2];

                    System.out.println(dni+"--"+nombre+"--"+departamento);
                }*/

//13.1) Obtener empleados con salarios superiores al promedio (ejem: 15.000€)

               /* String hql= "SELECT e FROM Empleado e LEFT JOIN EmpleadoDatosProf edp ON e.dni = edp.dni WHERE edp.sueldoBrutoAnual > (SELECT AVG(edp2.sueldoBrutoAnual) FROM EmpleadoDatosProf edp2)";

                List<Empleado> empleados=session.createQuery(hql, Empleado.class).getResultList();
                for(Empleado empleado:empleados){
                    System.out.println(empleado.getDni()+"--"+empleado.getNomEmp());
                }*/
               /* 14) Uso de parámetros nombrados

                14.1) Buscar empleados con un salario mayor al ingresado.*/
               /* BigDecimal sueldoBruto= BigDecimal.valueOf(30000);
                String hql = "SELECT e FROM Empleado e LEFT JOIN EmpleadoDatosProf edp ON e.dni=edp.dni WHERE edp.sueldoBrutoAnual=:sueldoBrutoAnual";
                List<Empleado> empleadoList=session.createQuery(hql, Empleado.class).setParameter("sueldoBrutoAnual",sueldoBruto).getResultList();
                for(Empleado empleado:empleadoList){
                    System.out.println(empleado.getDni()+"--"+empleado.getNomEmp());
                }*/
           /*     15) Actualizar entidades

                15.1) Aumentar el salario de empleados en un 10% para los que pertenecen a un departamento dado.*/
               /* int idDept=1;
                String hql = "UPDATE EmpleadoDatosProf edp SET edp.sueldoBrutoAnual = edp.sueldoBrutoAnual * 1.10WHERE edp.dni IN (SELECT e.dni FROM Empleado e WHERE e.idDepto.id = :idDepto)";
                Query query = session.createQuery(hql);
                query.setParameter("idDepto", idDept);

                int filasActualizadas = query.executeUpdate();
                System.out.println("Filas actualizadas: " + filasActualizadas);*/
//16.1) Eliminar empleados cuyo salario sea menor a
              /*  BigDecimal sueldo=BigDecimal.valueOf(34000);

                String hql = "DELETE FROM Empleado eWHERE e.dni IN (SELECT edp.dni FROM EmpleadoDatosProf edp WHERE edp.sueldoBrutoAnual < :sueldoBrutoAnual)";

                Query query = session.createQuery(hql).setParameter("sueldoBrutoAnual",sueldo);
                int filasAfectadas = query.executeUpdate();

                System.out.println("Empleados eliminados: " + filasAfectadas);*/

//16.2) Eliminar proyectos cuya fecha de fin sea menor a una dada
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date fechaLimite = sdf.parse("2025-12-31");

                List<Proyecto> proyectosAEliminar = session.createQuery(
                                "SELECT p FROM Proyecto p WHERE p.fFin < :fFin", Proyecto.class)
                        .setParameter("fFin", fechaLimite)
                        .getResultList();

                for (Proyecto proyecto : proyectosAEliminar) {
                    session.delete(proyecto); // Elimina en cascada los ProyectoSede relacionados
                    System.out.println("Proyecto eliminado: " + proyecto.getNomProy());
                }

                t.commit(); // Hacer commit correctamente
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("No se ha podido ejecutar el commit");
                if (t != null) {
                    t.rollback(); // Se ejecutará correctamente si hay un error
                }
            }
        } catch (Throwable ex) {
            System.err.println("Error al inicializar SessionFactory: " + ex);
            throw new ExceptionInInitializerError(ex);
        } finally {
            if (sessionFactory != null) {
                sessionFactory.close();
            }
        }
    }
}

/*
Inserción de datos
 t=s.beginTransaction();
         Sede sede= new Sede();
         sede.setNomSede("Málaga");
         s.save(sede);

         Departamento departamento = new Departamento();
         departamento.setNomDepto("INVESTIGACIÓN Y DESRROLO");
         departamento.setIdSede(sede);
         s.save(departamento);

         Departamento departamento1 = new Departamento();
         departamento1.setNomDepto("I+D");
         departamento1.setIdSede(sede);
         s.save(departamento1);

         Empleado empleado = new Empleado();
         empleado.setDni("56789012G");
         empleado.setNomEmp("SAMPER");
         empleado.setIdDepto(departamento);
         s.save(empleado);

         Empleado empleado1 = new Empleado();
         empleado1.setDni("56789088B");
         empleado1.setNomEmp("Manolo");
         empleado1.setIdDepto(departamento1);
         s.save(empleado1);
         t.commit();*/

//Inserción de empleados
              /*  Departamento departamento = (Departamento) session.createQuery("FROM Departamento d WHERE idDepto=:idDepto", Departamento.class).setParameter("idDepto",4).getSingleResult();
                Empleado empleado = new Empleado();
                empleado.setDni("56789012A");
                empleado.setNomEmp("Ana María");
                empleado.setIdDepto(departamento);
                session.save(empleado);

                Empleado empleado1 = new Empleado();
                empleado1.setDni("56789088C");
                empleado1.setNomEmp("Manolo Laranxeira");
                empleado1.setIdDepto(departamento);
                session.save(empleado1);
                Empleado empleado2 = new Empleado();
                empleado2.setDni("56789012S");
                empleado2.setNomEmp("Carlos Vispo");
                empleado2.setIdDepto(departamento);
                session.save(empleado2);
                Empleado empleado5 = new Empleado();
                empleado5.setDni("56789012P");
                empleado5.setNomEmp("Jose María");
                empleado5.setIdDepto(session.find(Departamento.class,4)); //Interesante tener en cuenta que no es necesario la consulta y se puede usar el método find mediante la session
                session.save(empleado5);

                Empleado empleado3 = new Empleado();
                empleado3.setDni("56789088H");
                empleado3.setNomEmp("Manolo Gonzalez");
                empleado3.setIdDepto(departamento);
                session.save(empleado3);
                Empleado empleado4 = new Empleado();
                empleado4.setDni("56789012I");
                empleado4.setNomEmp("Pablo Botana");
                empleado4.setIdDepto(departamento);
                session.save(empleado4);

*/
//Consulta para confirmar que tenemos los empleados recién creados, todos pertenencen al departamento 4, por lo tanto vamos a pedir los empleados con departamento 4

                /*String hqlEmpDep4="FROM Empleado e WHERE e.idDepto.idDepto=:idDepto";
                List<Empleado> empleadoList=session.createQuery(hqlEmpDep4, Empleado.class).setParameter("idDepto",4).getResultList();
                System.out.println("Empleado con departamento 4");
                for(Empleado empleado: empleadoList){
                    System.out.println(empleado.getNomEmp()+"--"+empleado.getDni());
                }*/

//Inserción de dos categoría de empleados
              /*  EmpleadoDatosProf empleadoDatosProf = new EmpleadoDatosProf();
                Empleado empleado=session.find(Empleado.class, "56789012I");
                empleadoDatosProf.setDni(empleado.getDni());
                empleadoDatosProf.setCategoria("C4");
                empleadoDatosProf.setSueldoBrutoAnual(BigDecimal.valueOf(40000.00));
                session.save(empleadoDatosProf);*/

               /* EmpleadoDatosProf empleadoDatosProf1 = new EmpleadoDatosProf();
                Empleado empleado1=session.find(Empleado.class, "56789088H");
                empleadoDatosProf1.setDni(empleado1.getDni());
                empleadoDatosProf1.setCategoria("A4");
                empleadoDatosProf1.setSueldoBrutoAnual(BigDecimal.valueOf(50000.00));
                session.save(empleadoDatosProf1);*/

//Consulta para confirmar que se hizo el insert
                /*String hqlEmpDatProf="FROM EmpleadoDatosProf e";
                List<EmpleadoDatosProf>empleadoDatosProfList=session.createQuery(hqlEmpDatProf,EmpleadoDatosProf.class).getResultList();
                for(EmpleadoDatosProf empleadoDatosProf:empleadoDatosProfList){
                    System.out.println(empleadoDatosProf.getDni()+"--"+empleadoDatosProf.getCategoria()+"--"+empleadoDatosProf.getSueldoBrutoAnual());
                }*/




//Inserción de proyectos
//Importante al insertar la fecha, ya que estamos creando una fecha de java y vamos a necesitar una fecha sql, por lo tanto la conversión es de vital importancia
                /*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date fechaInicio = sdf.parse("2025-01-01");
                Date fechaInicio1 = sdf.parse("2023-01-01");
                Date fechaInicio2 = sdf.parse("2025-02-01");

                Proyecto proyecto = new Proyecto();
                proyecto.setIdProy(7);
                proyecto.setfInicio(new java.sql.Date(fechaInicio.getTime()));
                proyecto.setNomProy("Proyecto Charle");
                session.save(proyecto);

                Proyecto proyecto1 = new Proyecto();
                proyecto1.setIdProy(8);
                proyecto1.setfInicio(new java.sql.Date(fechaInicio1.getTime()));
                proyecto1.setNomProy("Proyecto Bravo");
                session.save(proyecto1);

                Proyecto proyecto2 = new Proyecto();
                proyecto2.setIdProy(9);
                proyecto2.setfInicio(new java.sql.Date(fechaInicio2.getTime()));
                proyecto2.setNomProy("Proyecto Fox");
                session.save(proyecto2);*/

//Consulta de los proyectos

               /* String hqlPro ="From Proyecto";
                List<Proyecto> proyectoList=session.createQuery(hqlPro,Proyecto.class)
                        .getResultList();
                System.out.println("Proyectos de toda la empresa");
                for(Proyecto proyecto: proyectoList){
                    System.out.println(proyecto.getNomProy()+"---"+proyecto.getIdProy());
                }*/




