package entities;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "proyecto_sede")
@IdClass(ProyectoSedePK.class)
public class ProyectoSede implements Serializable {
    @Id
    @Column(name = "id_proy", nullable = false)
    private int idProy;
    @Id
    @Column(name = "id_sede", nullable = false)
    private int idSede;
    @ManyToOne
    @JoinColumn(name = "id_proy", insertable = false, updatable = false)
    private Proyecto proyecto;

    @ManyToOne
    @JoinColumn(name = "id_sede", insertable = false, updatable = false)
    private Sede sede;

    @Column(name = "f_inicio", nullable = false)
    private Date fInicio;
    @Column(name = "f_fin", nullable = false)
    private Date fFin;

    public ProyectoSede(){}

    public int getIdProy() {
        return idProy;
    }

    public void setIdProy(int idProy) {
        this.idProy = idProy;
    }

    public int getIdSede() {
        return idSede;
    }

    public void setIdSede(int idSede) {
        this.idSede = idSede;
    }

    public Date getfInicio() {
        return fInicio;
    }

    public void setfInicio(Date fInicio) {
        this.fInicio = fInicio;
    }

    public Date getfFin() {
        return fFin;
    }

    public void setfFin(Date fFin) {
        this.fFin = fFin;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProyectoSede that = (ProyectoSede) o;
        return idProy == that.idProy && idSede == that.idSede;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProy, idSede);
    }
}
