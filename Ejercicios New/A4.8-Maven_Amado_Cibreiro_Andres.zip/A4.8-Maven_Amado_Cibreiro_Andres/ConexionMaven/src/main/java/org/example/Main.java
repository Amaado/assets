package org.example;

import entities.Departamento;
import entities.Empleado;
import entities.Sede;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    private static SessionFactory sessionFactory;

    public static void main(String[] args) {
        Transaction t = null;
        try {
            // Configuración de Hibernate
            sessionFactory = new Configuration().configure().buildSessionFactory();

            // Abre una sesión para verificar la conexión
            try (Session session = sessionFactory.openSession()) {
                System.out.println("Conexión establecida con la base de datos.");
                t= session.beginTransaction();
                Sede sede= new Sede();
                sede.setNomSede("Málaga");
                session.save(sede);

                Departamento departamento = new Departamento();
                departamento.setNomDepto("INVESTIGACIÓN Y DESRROLO");
                departamento.setIdSede(sede);
                session.save(departamento);

                Departamento departamento1 = new Departamento();
                departamento1.setNomDepto("I+D");
                departamento1.setIdSede(sede);
                session.save(departamento1);

                Empleado empleado = new Empleado();
                empleado.setDni("56789012X");
                empleado.setNomEmp("SAMPER");
                empleado.setIdDepto(departamento);
                session.save(empleado);

                Empleado empleado1 = new Empleado();
                empleado1.setDni("56789088X");
                empleado1.setNomEmp("Manolo");
                empleado1.setIdDepto(departamento1);
                session.save(empleado1);
                t.commit();

                System.out.println("Commit exitoso");
            }catch (Exception e){
                e.printStackTrace();
                System.out.println("No se ha podido ejecutrar el commit");
                if(t != null){
                    t.rollback();
                }



            }
        } catch (Throwable ex) {
            // Manejo de errores al inicializar SessionFactory
            System.err.println("Error al inicializar SessionFactory: " + ex);
            throw new ExceptionInInitializerError(ex);
        } finally {
            if (sessionFactory != null) {
                sessionFactory.close();
            }
        }
    }
}
